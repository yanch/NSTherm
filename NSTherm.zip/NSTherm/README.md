# NSTherm: An Error-Bounded Network-Stochastic Fusion Thermal Simulator for Geometry-Adaptable Chiplets via Diffeomorphic Mapping and Neural-Guided Variance Reduction

`NSTherm` is an accurate and efficient network-stochastic fusion thermal simulator for geometry-adaptable chiplets. 

 This repository provides executable binaries and a part of the source code accepted in the paper "NSTherm: An Error-Bounded Network-Stochastic Fusion Thermal Simulator for Geometry-Adaptable Chiplets via Diffeomorphic Mapping and Neural-Guided Variance Reduction" (ICCAD 2025), along with usage instructions.

**Author:** Yuan Meng, Changhao Yan  
**Affiliation:** Fudan University CAD Lab  
**Version**: v0.1  
**Date:** 2025-10-20

##Copyright Notice​​
Copyright © 2025 Fudan University.
​​This work may be used for personal academic research, study, and teaching purposes.​​ However, ​​no part of this work may be used for any commercial purpose​​ whatsoever, including but not limited to sale, licensing, or promotion. Reproduction, distribution, or creation of derivative works for non-academic purposes requires prior written permission from Fudan University.

## General Usage Instructions
There are two main categories of use: NSTherm_NN and NSTherm_sto. NSTherm_NN corresponds to the neural network part, and NSTherm_sto corresponds to the stochastic part.

## Usage

Preparatory work:
Install CUDA based PyTorch 2.0.1.
Download train data and trained network weights at https://pan.baidu.com/s/1FNdeVo6DIJdrW5PH2yCRCA passwd: NST1 
The NSTherm_sto/lib64 folder contains the library files （.so） for the stochastic part. 
Configure the NSTherm_sto/env.sh file.
source NSTherm_sto/env.sh

1. Train a neural network. 
The detailed data description is written in NSTherm_NN/Readme_NN.txt. Run "python main.py --epochs N --device N --save-step N --test 0" for training.

2. Test the neural network.
Run "python main.py --test 1" for testing. NSTherm_NN/pred_test.npy is the prediced temperature.

3. Generate temperature gradient distribution files. Considering that the scale of the chip in the z direction is much smaller than that in the x and y directions, NSTherm only utilizes the gradients in the x and y directions. Use "NSTherm_sto/scripts/gen_grad.py" to generate temperature gradient distribution files.

4. Generate a configuration file for the stochastic part. Write a configuration file based on the "NSTherm_sto/sctipts/config_example.txt".  Refer to NSTherm_sto/Readme_sto.txt for detailed information.
    
5. Run the stochastic part.
Run the command "./test configX.txt". Check the files "T.txt" (Temperature distribution file) 


## Output format
T.txt :
"layer row col T"

layer is the index of a layer with a powermap (defined in the config file) 
row = int(y/dy)
col = int(x/dx)
dx = W/nx
dy = L/ny

## Contact
The code for the stochastic method part can be obtained via email at 22112020033@m.fudan.edu.cn or yanch@fudan.edu.cn. The user and the organization should be indicated in the email. Commercial use or distribution to third parties is prohibited. Any problems encountered during operation are welcome to be inquired by email 22112020033@m.fudan.edu.cn.