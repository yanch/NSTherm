import numpy as np
from scipy.ndimage import zoom

size = 160
dx = 0.02 / size

f_pred = f"XXXXX"
T_pred = np.load(f_pred)
T_pred = zoom(T_pred, size // 80, order=1)

ggy, ggx = np.gradient(T_pred, dx)


np.savetxt("gradx.txt", ggx, delimiter=" ", fmt="%.7e")
np.savetxt("grady.txt", ggy, delimiter=" ", fmt="%.7e")
