All 7 cases in the paper are placed in ./scripts. Each case contains a powermap, a starting point file, a configuration file, two temperature gradient file, a golden solution of the bottom layer obtained by fine discrete FEM, a predicted bottom layer temperature distribution of neural networks

1. Powermap files.
The power density is placed in the powermap file, with each power density separated by "" and each line separated by "\n".
The powermap in the paper is placed in "scripts/caseX/caseX_pmap.txt".

2. Starting point file.
Each line should be written in the format of "x'\t'y'\t'z'\n'". The unit of the coordinate is m.
The starting point file in the paper is placed in "scripts/caseX/pointX.txt.

In these cases, the coordinate in the x and y directions of the stochastic method range from 0 to 0.02m, while those of COMSOL and the neural network range from -0.01m to 0.01m. Therefore, when inputting the coordinates to the stochastic method, 0.01 should be added to both the x and y directions of comsol's coordinates.


3. Configuration file
Write the configuration file based on the "scripts/caseX/config1.txt".
