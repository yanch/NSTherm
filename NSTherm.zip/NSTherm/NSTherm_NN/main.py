import os
import torch
import time
import numpy as np
from torch.optim.lr_scheduler import StepLR
from utils import *
from module import *

import matplotlib.pyplot as plt


def main():
    ## hyperparameters
    args = ParseArgument()
    epochs = args.epochs
    device = args.device
    save_step = args.save_step
    test_model = args.test

    load_path = "./CheckPts/model_chkpts.pt"

    dim_br_shape = [16, 256, 256, 256, 256, 256, 256, 512, 512]
    dim_br_power = [4, 256, 256, 256, 256, 512, 512]
    dim_tr = [3, 256, 256, 256, 256, 256, 256, 512, 512]

    num_train = 28000
    num_test = 2000

    model_path = "CheckPts/model_chkpts.pt"
    os.makedirs("CheckPts", exist_ok=True)

    x_golden = np.load("./traindata/x_template.npy")
    f_shape = np.load("./traindata/f_shape.npy")
    f_power = np.load("./traindata/f_power.npy")
    T_golden = np.load("./traindata/T_template.npy")

    T_golden2 = T_golden[-2000:].copy()

    x_xy = x_golden[:, [0, 1]]
    x_z = x_golden[:, [2]]
    x_xy = (x_xy + 0.0099) / (0.0099 * 2)
    x_z = (x_z - 0.000145) / (0.00035 - 0.000145)

    x_golden = np.concatenate([x_xy, x_z], axis=1)

    f_shape_wl = f_shape[:, [0, 1, 4, 5, 8, 9, 12, 13]]
    f_shape_xy = f_shape[:, [2, 3, 6, 7, 10, 11, 14, 15]]
    f_shape_wl = (f_shape_wl - 0.0028) / (0.007 - 0.0028)
    f_shape_xy = (f_shape_xy + 0.0085) / (0.008 * 2)

    f_shape = np.concatenate([f_shape_wl, f_shape_xy], axis=1)

    f_power = (f_power - 2.3e10) / (np.max(f_power) - 2.3e10)
    T_golden = (T_golden - 293.15) / (403.15 - 293.15)

    ##########################
    f_shape_train = f_shape[:num_train, :]
    f_shape_test = f_shape[-num_test:, :]

    f_power_train = f_power[:num_train, :]
    f_power_test = f_power[-num_test:, :]

    T_train = T_golden[:num_train]
    T_test = T_golden[-num_test:]

    ## tensor
    T_test_tensor = torch.tensor(T_test, dtype=torch.float).to(device)
    f_shape_test_tensor = torch.tensor(f_shape_test, dtype=torch.float).to(device)
    f_power_test_tensor = torch.tensor(f_power_test, dtype=torch.float).to(device)

    T_train_tensor = torch.tensor(T_train, dtype=torch.float).to(device)
    f_shape_train_tensor = torch.tensor(f_shape_train, dtype=torch.float).to(device)
    f_power_train_tensor = torch.tensor(f_power_train, dtype=torch.float).to(device)

    x_tensor = torch.tensor(x_golden, dtype=torch.float).to(device)

    ## initialization
    model = MIONet_res(dim_br_shape, dim_br_power, dim_tr).to(device)
    print_model_parameters(model)

    model = model.float()
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
    scheduler = StepLR(optimizer, step_size=1000, gamma=0.98)

    if test_model == 0:
        train_loss = np.zeros((args.epochs, 1))
        test_loss = np.zeros((args.epochs, 1))

        ## training
        def train(epoch, f1, f2, x, y):
            model.train()

            def closure():
                optimizer.zero_grad()

                loss = model.loss(f1, f2, x, y)
                train_loss[epoch, 0] = loss

                loss.backward()
                return loss

            optimizer.step(closure)
            scheduler.step()

        ## Iterations
        print("start training...", flush=True)
        tic = time.time()
        for epoch in range(0, epochs):

            ## Training
            train(
                epoch,
                f_shape_train_tensor,
                f_power_train_tensor,
                x_tensor,
                T_train_tensor,
            )

            ## Validating
            loss_tmp = to_numpy(
                model.loss(
                    f_shape_test_tensor, f_power_test_tensor, x_tensor, T_test_tensor
                )
            )
            test_loss[epoch, 0] = loss_tmp

            ## testing error
            if epoch % 100 == 0:
                print(
                    f"Epoch: {epoch}, Train Loss: {train_loss[epoch, 0]:.6f}, Test Loss: {test_loss[epoch, 0]:.6f}",
                    flush=True,
                )

            ## Save model
            if (epoch + 1) % save_step == 0:
                torch.save(
                    {
                        "model_state_dict": model.state_dict(),
                        "optimizer_state_dict": optimizer.state_dict(),
                    },
                    model_path,
                )

        toc = time.time()

        print(f"total training time: {int((toc-tic)/60)} min", flush=True)
        np.savetxt("./train_loss.txt", train_loss)
        np.savetxt("./test_loss.txt", test_loss)

        ## plot loss function
        num_epoch = train_loss.shape[0]
        train_step = np.linspace(1, num_epoch, num_epoch)

        ## plot loss
        fig = plt.figure(constrained_layout=False, figsize=(6, 6))
        gs = fig.add_gridspec(1, 1)

        ax = fig.add_subplot(gs[0])
        ax.plot(
            train_step, train_loss.mean(axis=1), color="blue", label="Training Loss"
        )
        ax.plot(
            train_step,
            test_loss.mean(axis=1),
            color="red",
            label="Test Loss",
            linestyle="dashed",
        )
        ax.set_yscale("log")
        ax.set_ylabel("Loss")
        ax.set_xlabel("Epochs")
        ax.legend(loc="upper left")
        fig.savefig("./loss_his.png")

    else:
        checkpoint = torch.load(load_path)
        model.load_state_dict(checkpoint["model_state_dict"])
        model.eval()

        T_train_pred = model.forward(
            f_shape_train_tensor, f_power_train_tensor, x_tensor
        )

        start_time = time.time()
        with torch.no_grad():
            T_test_pred = model.forward(
                f_shape_test_tensor, f_power_test_tensor, x_tensor
            )
        end_time = time.time()

        print(f"Inference time: {(end_time - start_time):.6f} s")

        T_test_pred = T_test_pred.cpu().detach().numpy() * (403.15 - 293.15) + 293.15
        abs_err = np.abs(T_golden2 - T_test_pred)

        mean_err = np.mean(abs_err, axis=1)
        max_err = np.max(abs_err, axis=1)

        print(f"Mean Err = {np.mean(mean_err):.2f} K")
        print(f"Mean Max Err = {np.mean(max_err):.2f} K")

        np.save("label_test", T_golden2)
        np.save("pred_test", T_test_pred)


if __name__ == "__main__":
    main()
