import torch
import torch.nn as nn


class ResidualBlock(nn.Module):
    def __init__(self, in_features, out_features):
        super(ResidualBlock, self).__init__()
        self.fc1 = nn.Linear(in_features, out_features)

        self.silu = nn.SiLU()
        self.fc2 = nn.Linear(out_features, out_features)

        if in_features != out_features:
            self.downsample = nn.Sequential(nn.Linear(in_features, out_features))
        else:
            self.downsample = None

    def forward(self, x):
        identity = x

        out = self.fc1(x)
        out = self.silu(out)
        out = self.fc2(out)

        if self.downsample is not None:
            identity = self.downsample(x)

        out += identity
        out = self.silu(out)
        return out


class MIONet_res(nn.Module):
    def __init__(self, branch1_dim, branch2_dim, trunk_dim):
        super(MIONet_res, self).__init__()
        ## build branch net
        modules = []
        for i, h_dim in enumerate(branch1_dim):
            if i == 0:
                in_channels = h_dim
            else:
                modules.append(nn.Sequential(ResidualBlock(in_channels, h_dim)))
                in_channels = h_dim
        self._branch1 = nn.Sequential(*modules)

        modules = []
        for i, h_dim in enumerate(branch2_dim):
            if i == 0:
                in_channels = h_dim
            else:
                modules.append(nn.Sequential(ResidualBlock(in_channels, h_dim)))
                in_channels = h_dim
        self._branch2 = nn.Sequential(*modules)

        ## build trunk net
        modules = []
        for i, h_dim in enumerate(trunk_dim):
            if i == 0:
                in_channels = h_dim
            else:
                modules.append(nn.Sequential(nn.Linear(in_channels, h_dim), nn.SiLU()))
                in_channels = h_dim
        self._trunk = nn.Sequential(*modules)

    def forward(self, f1, f2, x):

        y_br1 = self._branch1(f1)
        y_br2 = self._branch2(f2)
        y_br = y_br1 * y_br2

        y_tr = self._trunk(x)
        y_out = torch.einsum("ij,kj->ik", y_br, y_tr)

        return y_out

    def loss(self, f1, f2, x, y):
        y_out = self.forward(f1, f2, x)
        loss = ((y_out - y) ** 2).mean()
        return loss
