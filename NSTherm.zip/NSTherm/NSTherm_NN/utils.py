import numpy as np
import torch
import argparse


def ParseArgument():
    parser = argparse.ArgumentParser(description="MIONet for Chiplet")
    parser.add_argument(
        "--epochs",
        type=int,
        default=150000,
        metavar="N",
        help="number of epochs to train (default: 150000)",
    )
    parser.add_argument(
        "--device",
        type=str,
        default="cuda:0",
        metavar="N",
        help="computing device (default: GPU)",
    )
    parser.add_argument(
        "--save-step",
        type=int,
        default=10000,
        metavar="N",
        help="save_step (default: 10000)",
    )

    parser.add_argument(
        "--test",
        type=int,
        default=0,
        metavar="N",
        help="default training, testing as 1",
    )

    args = parser.parse_args()
    return args


def to_numpy(input):
    if isinstance(input, torch.Tensor):
        return input.detach().cpu().numpy()
    elif isinstance(input, np.ndarray):
        return input
    else:
        raise TypeError(
            "Unknown type of input, expected torch.Tensor or "
            "np.ndarray, but got {}".format(type(input))
        )


def print_model_parameters(model):
    total_params = 0
    for name, param in model.named_parameters():
        if param.requires_grad:
            num_params = param.numel()
            print(f"{name}: {num_params} parameters")
            total_params += num_params
    print(f"Total trainable parameters: {total_params}")
