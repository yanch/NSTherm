usage: python main.py [-h] [--epochs N] [--device N] [--save-step N] [--test N]

MIONet for Chiplet

options:
  -h, --help     show this help message and exit
  --epochs N     number of epochs to train (default: 150000)
  --device N     computing device (default: GPU)
  --save-step N  save_step (default: 10000)
  --test N       default training, testing as 1

traindata:
    x_theta.npy: (30000, 8000, 3) The coordinates on the original domain. 30000 cases are contained, and for each case, the lowest and middle layers are included, totaling 8000 points. The topmost layer has not been trained.  
    x_template.npy: (8000, 3) The coordinates on the template domain.  The lowest and middle layers are included, totaling 8000 points.
    f_power.npy: (30000, 4) The power density for 30000 cases. For eace case, power density on 4 dies are given.
    f_shape.npy: (30000, 16) The shape parameters for 30000 cases. For each case, W, L, X, Y for 4 dies are given. (W, L) is the width and length  of a die. (X, Y) is the coordinate of the center point of a die.
    T_template.npy: (30000, 8000) Rough temperature labels of 30000 cases.  

    (<f_shape, f_power, x_template>, T_template) is used to train NN.

    (x_theta, T_template) can be used to obtain rough temperature distributions.

    In the paper, the first 28000 cases are used for training the NN, and the last 2000 are used for testing. 
    


pred_test.npy: (2000, 8000) Temperature predicted by NN.
label_test.npy: (2000, 8000) Rough temperature label for test. 

(x_theta, pred_test) can be used to obtain temperature distributions predicted by NN.

    